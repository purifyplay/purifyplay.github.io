#!/usr/bin/python3

# Copyright 2021 Offensive Security
# SPDX-license-identifier: GPL-3.0-only

from setuptools import setup

setup()
