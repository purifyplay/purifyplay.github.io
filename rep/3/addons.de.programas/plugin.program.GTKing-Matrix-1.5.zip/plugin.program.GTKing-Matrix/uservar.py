Skip to content

PullsIssues

Marketplace

Explore

 

￼ 

gtkingbuild/Repo-GTKingPublic

 Unwatch 1

 Star1

 Fork0

Code

Issues

Pull requests

Actions

Projects

Wiki

Security

Insights

More

 master 

Repo-GTKing/matrix/plugin.program.GTKing-Matrix/uservar.py / Jump to 

Go to file

￼

gtkingbuild 1

Latest commit bb4af8d 4 hours ago History

 1 contributor

131 lines (122 sloc)  6.31 KB

RawBlame

  

import xbmcaddon import os ########################################################## Global Variables - DON'T EDIT!!! ##########################################################ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')PATH = xbmcaddon.Addon().getAddonInfo('path')ART = os.path.join(PATH, 'resources', 'media')######################################################### ########################################################## User Edit Variables ##########################################################ADDONTITLE = '[COLOR azure][B]GTKing[/B][/COLOR] [COLOR lime][B]MATRIX[/B][/COLOR]'BUILDERNAME = 'JoseaTEBA & DavidZgZ'EXCLUDES = [ADDON_ID, 'repository.GTKing-Matrix']# Text File with build info in it.BUILDFILE = 'https://raw.githubusercontent.com/gtkingbuild/Repo-GTKing/master/wizardfiles/builds.txt'# How often you would like it to check for build updates in days# 0 being every startup of kodiUPDATECHECK = 0# Text File with apk info in it. Leave as 'http://' to ignoreAPKFILE = 'http://'# Text File with Youtube Videos urls. Leave as 'http://' to ignoreYOUTUBETITLE = ''YOUTUBEFILE = 'http://'# Text File for addon installer. Leave as 'http://' to ignoreADDONFILE = 'http://'# Text File for advanced settings. Leave as 'http://' to ignoreADVANCEDFILE = 'https://raw.githubusercontent.com/gtkingbuild/gtkingbuild.github.io/master/wizard/xml/Advanced.json'######################################################### ########################################################## Theming Menu Items ########################################################### If you want to use locally stored icons the place them in the Resources/Art/# folder of the wizard then use os.path.join(ART, 'imagename.png')# do not place quotes around os.path.join# Example: ICONMAINT = os.path.join(ART, 'mainticon.png')# ICONSETTINGS = 'https://www.yourhost.com/repo/wizard/settings.png'# Leave as http:// for default iconICONBUILDS = os.path.join(ART, 'builds.png')ICONMAINT = os.path.join(ART, 'maintenance.png')ICONSPEED = os.path.join(ART, 'speed.png')ICONAPK = os.path.join(ART, 'apkinstaller.png')ICONADDONS = os.path.join(ART, 'addoninstaller.png')ICONYOUTUBE = os.path.join(ART, 'youtube.png')ICONSAVE = os.path.join(ART, 'savedata.png')ICONTRAKT = os.path.join(ART, 'keeptrakt.png')ICONREAL = os.path.join(ART, 'keepdebrid.png')ICONLOGIN = os.path.join(ART, 'keeplogin.png')ICONCONTACT = os.path.join(ART, 'information.png')ICONSETTINGS = os.path.join(ART, 'settings.png')# Hide the section separators 'Yes' or 'No'HIDESPACERS = 'No'# Character used in separator#SPACER = '♠'SPACER = '<->' # You can edit these however you want, just make sure that you have a %s in each of the# THEME's so it grabs the text from the menu itemCOLOR1 = 'limegreen'COLOR2 = 'white'COLOR3 = 'dodgerblue'COLOR4 = 'turquoise'# Primary menu items / {0} is the menu item and is requiredTHEME1 = u'[COLOR {color1}][COLOR {color1}][B]-[/B][/COLOR][COLOR {color2}][B][/B][COLOR {color1}][/COLOR] [COLOR {color2}]{{}}[/COLOR]'.format(color1=COLOR1, color2=COLOR2, color3=COLOR3, color4=COLOR4)# Build Names / {0} is the menu item and is requiredTHEME2 = u'[COLOR {color1}]{{}}[/COLOR]'.format(color1=COLOR3)# Alternate items / {0} is the menu item and is requiredTHEME3 = u'[COLOR {color1}]{{}}[/COLOR]'.format(color1=COLOR1)# Current Build Header / {0} is the menu item and is requiredTHEME4 = u'[COLOR {color1}][B]Build Actual:[/B][/COLOR] [COLOR {color2}]{{}}[/COLOR]'.format(color1=COLOR1, color2=COLOR2, color3=COLOR3, color4=COLOR4)# Current Theme Header / {0} is the menu item and is requiredTHEME5 = u'[COLOR {color1}][B]Parche Actual:[/B][/COLOR] [COLOR {color2}]{{}}[/COLOR]'.format(color1=COLOR1, color2=COLOR2, color3=COLOR3, color4=COLOR4)# Current Theme Header / {0} is the menu item and is requiredTHEME6 = u'[COLOR {color1}]{{}}[/COLOR]'.format(color1=COLOR4) # Message for Contact Page# Enable 'Contact' menu item 'Yes' hide or 'No' dont hideHIDECONTACT = 'No'# You can add \n to do line breaksCONTACT = 'Gracias por elegir [COLOR azure]GTKingBuild.[/COLOR]\n\nContáctenos en el Grupo Telegram [COLOR white]https://t.me/beelinkking[/COLOR]'# Images used for the contact window. http:// for default icon and fanartCONTACTICON = os.path.join(ART, 'qricon.png')CONTACTFANART = 'http://'######################################################### ########################################################## Auto Update For Those With No Repo ########################################################### Enable Auto Update 'Yes' or 'No'AUTOUPDATE = 'Yes'# Url to wizard versionWIZARDFILE = 'https://raw.githubusercontent.com/gtkingbuild/Repo-GTKing/master/wizardfiles/builds.txt' ######################################################### ########################################################## Auto Install Repo If Not Installed ########################################################### Enable Auto Install 'Yes' or 'No'AUTOINSTALL = 'No'# Addon ID for the repositoryREPOID = 'repository.GTKing-Matrix'# Url to Addons.xml file in your repo folder(this is so we can get the latest version)REPOADDONXML = 'https://raw.githubusercontent.com/gtkingbuild/Repo-GTKing/master/matrix/zips/addons.xml'# Url to folder zip is located inREPOZIPURL = 'https://raw.githubusercontent.com/gtkingbuild/Repo-GTKing/master/matrix/zips/repository.GTKing-Matrix/'######################################################### ########################################################## Notification Window ########################################################### Enable Notification screen Yes or NoENABLE = 'Yes'# Url to notification fileNOTIFICATION = 'https://raw.githubusercontent.com/gtkingbuild/Repo-GTKing/master/wizardfiles/GTKing/Notify.txt'# Use either 'Text' or 'Image'HEADERTYPE = 'Image'# Font size of headerFONTHEADER = ''HEADERMESSAGE = '[COLOR azure][B]GTKing [COLOR lime][B]MATRIX[/B][/COLOR]'# url to image if using Image 424x180HEADERIMAGE = 'https://i.imgur.com/7tsuHwV.png'# Font for Notification WindowFONTSETTINGS = ''# Background for Notification WindowBACKGROUND = 'https://i.imgur.com/Go38Mga.png'#########################################################

© 2021 GitHub, Inc.

Terms

Privacy

Security

Status

Docs

Contact GitHub

Pricing

API

Training

Blog

About

Loading complete


