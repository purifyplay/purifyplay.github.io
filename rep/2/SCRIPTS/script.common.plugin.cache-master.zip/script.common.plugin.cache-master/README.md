<img src="icon.png" width="256" height="256" />

# Common plugin cache 
###### script.common.plugin.cache

![Build Status](https://img.shields.io/travis/anxdpanic/script.common.plugin.cache/master.svg)
![License](https://img.shields.io/badge/license-GPL--3.0--only-success.svg)
![Kodi Version](https://img.shields.io/badge/kodi-jarvis%2B-success.svg)
![Contributors](https://img.shields.io/github/contributors/anxdpanic/script.common.plugin.cache.svg)

A common caching API for Kodi add-ons
